# Projeto-Compilador

Utilizar o comando .\run.bat para compilar o projeto e rodar de forma automatica.

Utilizar o arquivo teste.txt como principal para os teste sintaticos do proc.